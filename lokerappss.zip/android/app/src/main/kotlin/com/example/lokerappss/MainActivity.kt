package com.example.lokerappss

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
